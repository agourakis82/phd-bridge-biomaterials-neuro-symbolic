# Release Notes — v2025.08.17

## Added
- PDF (v2) with bilingual cover and technical footer (ORCID/Version/DOI placeholder).
- CITATION.cff, .zenodo.json, metadata.yaml, .gitattributes (Git LFS), LICENSE, README badges.
- Email template to PIs.
- GitHub Actions workflow to attach assets on tag push.

## How to cite
Demetrios Agourakis. *Memória Estendida — Plano PhD & Publicação (Brasil): ponte Biomateriais ↔ Neurociência (SWOW, grafos semânticos).* v2025.08.17. DOI: 10.XXXX/zenodo.XXXXXXX.
