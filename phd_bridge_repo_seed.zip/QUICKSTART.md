# Quickstart — Repo + Release + Zenodo DOI

## 1) Initialize and push
git init
git lfs install
git add -A
git commit -m "Snapshot: Memória Estendida + registros"
git branch -M main
git remote add origin https://github.com/agourakis82/phd-bridge-biomaterials-neuro-symbolic.git
git push -u origin main

## 2) Tag a version to trigger GitHub Release
git tag v2025.08.17
git push origin v2025.08.17

## 3) Zenodo
- In Zenodo: Account → GitHub → enable repo
- The tag above creates a Release; Zenodo will capture it automatically.
- Open the Zenodo draft, edit metadata (title, author, ORCID, license), and **Publish**.
- Copy the DOI and update README.md and CITATION.cff.

## 4) Update DOI in files
# Replace placeholder 10.XXXX/zenodo.XXXXXXX with the real DOI
# Then commit & tag a patch
git add README.md CITATION.cff .zenodo.json
git commit -m "docs: update DOI to REAL_DOI"
git push
git tag v2025.08.17-1
git push origin v2025.08.17-1
